package com.mohamed.tapcounter

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/** Today's date as "2026-10-13" */
fun today(): String = LocalDate.now().toString()

class MainActivity : Activity() {

    /** history: date ("2026-10-13") -> [taps that day, times target completed that day] */
    data class Counter(
        var name: String,
        var target: Int,
        var remaining: Int,
        var lastDay: String = today(),
        val history: MutableMap<String, IntArray> = mutableMapOf()
    )


    private val prefs by lazy { getSharedPreferences("counter", Context.MODE_PRIVATE) }
    private val counters = mutableListOf<Counter>()
    private var selected = 0
    private val current get() = counters[selected]

    private var soundOn = true
    private var volumeKeysOn = true

    private lateinit var countText: TextView
    private lateinit var statusText: TextView
    private lateinit var todayText: TextView
    private lateinit var targetInput: EditText
    private lateinit var tapArea: View
    private lateinit var spinner: Spinner
    private lateinit var spinnerAdapter: ArrayAdapter<String>
    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        countText = findViewById(R.id.countText)
        statusText = findViewById(R.id.statusText)
        todayText = findViewById(R.id.todayText)
        targetInput = findViewById(R.id.targetInput)
        tapArea = findViewById(R.id.tapArea)
        spinner = findViewById(R.id.counterSpinner)
        vibrator = getSystemService(Vibrator::class.java)

        load()

        // Counter picker
        spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, mutableListOf<String>())
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = spinnerAdapter
        refreshSpinner()
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, position: Int, id: Long) {
                if (position != selected) {
                    selected = position
                    save()
                    showCurrent()
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Options
        findViewById<Switch>(R.id.soundSwitch).apply {
            isChecked = soundOn
            setOnCheckedChangeListener { _, on -> soundOn = on; save() }
        }
        findViewById<Switch>(R.id.volumeSwitch).apply {
            isChecked = volumeKeysOn
            setOnCheckedChangeListener { _, on -> volumeKeysOn = on; save() }
        }

        tapArea.setOnClickListener { onTap() }
        findViewById<Button>(R.id.setButton).setOnClickListener { applyTarget() }
        findViewById<Button>(R.id.resetButton).setOnClickListener { reset() }
        findViewById<Button>(R.id.addButton).setOnClickListener { addCounterDialog() }
        findViewById<Button>(R.id.deleteButton).setOnClickListener { deleteCounterDialog() }
        findViewById<Button>(R.id.historyButton).setOnClickListener { showHistory() }

        showCurrent()
    }

    override fun onResume() {
        super.onResume()
        if (checkNewDay()) render()
    }

    /** At the start of a new day every counter starts again from its target. */
    private fun checkNewDay(): Boolean {
        val t = today()
        var changed = false
        counters.forEach {
            if (it.lastDay != t) {
                it.remaining = it.target
                it.lastDay = t
                changed = true
            }
        }
        if (changed) save()
        return changed
    }

    private fun todayStats(c: Counter = current): IntArray =
        c.history.getOrPut(today()) { intArrayOf(0, 0) }

    // ---------- Volume buttons count as taps ----------
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (volumeKeysOn &&
            (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
        ) {
            if (event.repeatCount == 0) onTap()   // ignore auto-repeat when held
            return true                            // don't change the volume
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (volumeKeysOn &&
            (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)
        ) return true
        return super.onKeyUp(keyCode, event)
    }

    // ---------- Counting ----------
    private fun onTap() {
        checkNewDay()
        val c = current
        if (c.remaining <= 0) {
            Toast.makeText(this, "Done! Press Reset to start again", Toast.LENGTH_SHORT).show()
            return
        }
        c.remaining--
        val stats = todayStats(c)
        stats[0]++                          // taps today
        if (c.remaining == 0) stats[1]++    // completed today
        save()
        if (c.remaining == 0) {
            vibrate(longArrayOf(0, 300, 150, 300))
            if (soundOn) playDoneSound()
        } else {
            vibrate(longArrayOf(0, 25))
        }
        render()
    }

    private fun applyTarget() {
        val value = targetInput.text.toString().toIntOrNull()
        if (value == null || value <= 0) {
            Toast.makeText(this, "Enter a number greater than 0", Toast.LENGTH_SHORT).show()
            return
        }
        current.target = value
        current.remaining = value
        save()
        hideKeyboard()
        render()
    }

    private fun reset() {
        current.remaining = current.target
        save()
        render()
    }

    // ---------- Multiple counters ----------
    private fun addCounterDialog() {
        val nameInput = EditText(this).apply {
            hint = "Name (e.g. Morning)"
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val targetField = EditText(this).apply {
            hint = "Target count"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("33")
        }
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 16, 48, 0)
            addView(nameInput)
            addView(targetField)
        }
        AlertDialog.Builder(this)
            .setTitle("New counter")
            .setView(box)
            .setPositiveButton("Add") { _, _ ->
                val name = nameInput.text.toString().trim().ifEmpty { "Counter ${counters.size + 1}" }
                val t = targetField.text.toString().toIntOrNull()?.takeIf { it > 0 } ?: 33
                counters.add(Counter(name, t, t))
                selected = counters.lastIndex
                save()
                refreshSpinner()
                showCurrent()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteCounterDialog() {
        if (counters.size <= 1) {
            Toast.makeText(this, "You need at least one counter", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Delete \"${current.name}\"?")
            .setPositiveButton("Delete") { _, _ ->
                counters.removeAt(selected)
                selected = selected.coerceAtMost(counters.lastIndex)
                save()
                refreshSpinner()
                showCurrent()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refreshSpinner() {
        spinnerAdapter.clear()
        spinnerAdapter.addAll(counters.map { it.name })
        spinnerAdapter.notifyDataSetChanged()
        spinner.setSelection(selected)
    }

    // ---------- Display ----------
    private fun showCurrent() {
        targetInput.setText(current.target.toString())
        render()
    }

    private fun render() {
        val c = current
        countText.text = c.remaining.toString()
        if (c.remaining == 0) {
            statusText.text = "Done ✓"
            tapArea.setBackgroundColor(Color.parseColor("#1B5E20"))
        } else {
            statusText.text = "${c.target - c.remaining} of ${c.target} — tap to count"
            tapArea.setBackgroundColor(Color.parseColor("#1E2A35"))
        }
        val s = c.history[today()] ?: intArrayOf(0, 0)
        todayText.text = "Today: ${s[0]}" + if (s[1] > 0) "  ·  ${s[1]}× completed" else ""
    }

    // ---------- History ----------
    private fun showHistory() {
        val c = current
        val days = c.history.filter { it.value[0] > 0 }.toSortedMap(compareByDescending { it })
        val message = if (days.isEmpty()) {
            "No counts yet."
        } else {
            val fmt = DateTimeFormatter.ofPattern("EEE d MMM yyyy")
            val total = days.values.sumOf { it[0] }
            val lines = days.entries.joinToString("\n") { (day, s) ->
                val label = if (day == today()) "Today" else LocalDate.parse(day).format(fmt)
                val done = if (s[1] > 0) "  ✓×${s[1]}" else ""
                "$label:  ${s[0]}$done"
            }
            "Total: $total over ${days.size} day(s)\n\n$lines"
        }
        AlertDialog.Builder(this)
            .setTitle("${c.name} — daily counts")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .setNeutralButton("Clear history") { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle("Clear all history for \"${c.name}\"?")
                    .setPositiveButton("Clear") { _, _ ->
                        c.history.clear(); save(); render()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .show()
    }

    // ---------- Sound & vibration ----------
    private fun playDoneSound() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            RingtoneManager.getRingtone(this, uri)?.play() ?: beep()
        } catch (e: Exception) {
            beep()
        }
    }

    private fun beep() {
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 100)
                .startTone(ToneGenerator.TONE_PROP_ACK, 400)
        } catch (_: Exception) { }
    }

    private fun vibrate(pattern: LongArray) {
        val v = vibrator ?: return
        if (v.hasVibrator()) v.vibrate(VibrationEffect.createWaveform(pattern, -1))
    }

    private fun hideKeyboard() {
        val imm = getSystemService(InputMethodManager::class.java)
        imm?.hideSoftInputFromWindow(targetInput.windowToken, 0)
        targetInput.clearFocus()
    }

    // ---------- Saving ----------
    private fun load() {
        counters.clear()
        val json = prefs.getString("counters", null)
        if (json != null) {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val c = Counter(
                    o.getString("name"), o.getInt("target"), o.getInt("remaining"),
                    o.optString("lastDay", today())
                )
                o.optJSONObject("history")?.let { h ->
                    h.keys().forEach { day ->
                        val v = h.getJSONArray(day)
                        c.history[day] = intArrayOf(v.getInt(0), v.getInt(1))
                    }
                }
                counters.add(c)
            }
        }
        if (counters.isEmpty()) {
            // First run, or upgrading from the single-counter version
            val t = prefs.getInt("target", 33)
            counters.add(Counter("Counter 1", t, prefs.getInt("remaining", t)))
        }
        selected = prefs.getInt("selected", 0).coerceIn(0, counters.lastIndex)
        soundOn = prefs.getBoolean("sound", true)
        volumeKeysOn = prefs.getBoolean("volumeKeys", true)
    }

    private fun save() {
        val arr = JSONArray()
        counters.forEach { c ->
            val h = JSONObject()
            c.history.forEach { (day, s) -> h.put(day, JSONArray().put(s[0]).put(s[1])) }
            arr.put(
                JSONObject()
                    .put("name", c.name).put("target", c.target).put("remaining", c.remaining)
                    .put("lastDay", c.lastDay).put("history", h)
            )
        }
        prefs.edit()
            .putString("counters", arr.toString())
            .putInt("selected", selected)
            .putBoolean("sound", soundOn)
            .putBoolean("volumeKeys", volumeKeysOn)
            .apply()
    }
}
