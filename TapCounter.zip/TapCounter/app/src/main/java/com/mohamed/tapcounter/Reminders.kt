package com.mohamed.tapcounter

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import org.json.JSONArray
import java.time.ZonedDateTime

/**
 * One daily reminder for all counters.
 * Saved in prefs as "reminder" = minutes after midnight (e.g. 21:00 -> 1260), or -1 when off.
 */
object Reminders {
    private const val CHANNEL = "daily_reminder"
    private const val PREFS = "counter"

    fun getTime(ctx: Context): Int = prefs(ctx).getInt("reminder", -1)

    fun setTime(ctx: Context, minutes: Int) {
        prefs(ctx).edit().putInt("reminder", minutes).apply()
        if (minutes >= 0) schedule(ctx) else cancel(ctx)
    }

    /** Schedule the next reminder (today if the time is still ahead, otherwise tomorrow). */
    fun schedule(ctx: Context) {
        val minutes = getTime(ctx)
        if (minutes < 0) { cancel(ctx); return }
        val now = ZonedDateTime.now()
        var at = now.toLocalDate().atTime(minutes / 60, minutes % 60).atZone(now.zone)
        if (!at.isAfter(now)) at = at.plusDays(1)
        val ms = at.toInstant().toEpochMilli()

        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = alarmIntent(ctx)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        }
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java)?.cancel(alarmIntent(ctx))
    }

    /** Called at the reminder time: notify only if some counter hasn't reached its target today. */
    fun check(ctx: Context) {
        val json = prefs(ctx).getString("counters", null)
        if (json != null) {
            val day = today()
            val arr = JSONArray(json)
            val unfinished = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val stats = o.optJSONObject("history")?.optJSONArray(day)
                val taps = stats?.optInt(0) ?: 0
                val done = stats?.optInt(1) ?: 0
                if (done == 0) unfinished.add("${o.getString("name")}: $taps of ${o.getInt("target")}")
            }
            if (unfinished.isNotEmpty()) notify(ctx, unfinished)
        }
        schedule(ctx) // set up tomorrow's reminder
    }

    private fun notify(ctx: Context, unfinished: List<String>) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Daily reminder", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (unfinished.size == 1) "Target not reached today" else "${unfinished.size} targets not reached today"
        val body = unfinished.joinToString("\n")
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(unfinished.first() + if (unfinished.size > 1) " …" else "")
            .setStyle(Notification.BigTextStyle().bigText("$body\nTap to continue."))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
    }

    private fun alarmIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 0, Intent(ctx, ReminderReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}

/** Fires at the reminder time. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) = Reminders.check(ctx)
}

/** Re-creates the reminder after the phone restarts, the app updates, or the clock changes. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) = Reminders.schedule(ctx)
}
