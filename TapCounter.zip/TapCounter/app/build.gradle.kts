plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mohamed.tapcounter"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mohamed.tapcounter"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "1.4"
    }

    // Fixed signing key so new builds install over the old app (keeps your data)
    signingConfigs {
        getByName("debug") {
            storeFile = file("tapcounter.keystore")
            storePassword = "tapcounter123"
            keyAlias = "tapcounter"
            keyPassword = "tapcounter123"
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
